use ksq_sql;
drop procedure if exists car_data_details;
DELIMITER \\
CREATE PROCEDURE car_data_details
(
in yr int
)
BEGIN
  select car_name, count(*)  from car_Data
where year=yr
group by 1
order by 2 desc;
END;


call  car_data_details(2018);




drop procedure if exists car_data_details_1;
DELIMITER \\
CREATE PROCEDURE car_data_details_1
(
in yr int
)
BEGIN
  select count(car_name)  from car_Data
where year=yr;
END;

call car_data_details_1(2014);



select * from sales;

use ksr_sql;
drop procedure if exists sales_details;
DELIMITER \\
CREATE PROCEDURE sales_details
(
in from_date date,
in to_date date
)
BEGIN
  select sum(sales) from sales
where date between from_date and to_date;
END;
\\ 

select sum(sales) from sales 
where date between '2020-01-01' and '2020-12-31';
5535


call sales_details('2019-01-01');
9250

select * from sales;

call sales_details('2019-11-10', '2020-11-10');

call sales_details('2018-11-10', '2019-11-10');





select * from sales;

#1. client asks how much sales happened lasy year? 2019

select sum(sales) from sales 
where date 
between '2019-01-01' and '2019-12-31'
;

select sum(sales) from sales 
where date between '2020-01-01' and '2020-12-31';













#DEFINE TYPE OF CUSTUMER
DROP PROCEDURE IF EXISTS CUSTUMER_STATUS;
DELIMITER $$
CREATE  PROCEDURE CUSTUMER_STATUS(
 IN V_ID INT,
 OUT V_STATUS VARCHAR(20)
 )
BEGIN
 DECLARE PURCHASE INT DEFAULT 0;
SELECT SUM(SALES) INTO PURCHASE FROM SALES 
 WHERE USER_ID = V_ID
 GROUP BY USER_ID;
 IF PURCHASE > 10000 THEN
        SET V_STATUS = 'PLATINUM';
ELSEIF PURCHASE <= 5000 THEN
        SET V_STATUS = 'SILVER';
ELSE
        SET V_STATUS = 'GOLD';
END IF;
 END;
$$


CALL CUSTUMER_STATUS(3, @V_STATUS);
SELECT @V_STATUS;



DROP PROCEDURE IF EXISTS GetCustomerShipping;
DELIMITER $$
CREATE PROCEDURE GetCustomerShipping(
	IN P_ID  INT, 
	OUT pShipping  VARCHAR(50)
)
BEGIN
    DECLARE V_ADDRESS VARCHAR(100);
SELECT 
    ADDRESS
INTO V_ADDRESS FROM
    custumer_info_1
WHERE
    ID = P_ID;
   CASE V_ADDRESS
		WHEN  'BANGALORE' THEN
		   SET pShipping = '1-day Shipping';
		WHEN 'CHENNAI' THEN
		   SET pShipping = '2-day Shipping';
           WHEN 'MUMBAI' THEN
		   SET pShipping = '3-day Shipping';
           WHEN 'HYDERABAD' THEN
		   SET pShipping = '4-day Shipping';
		ELSE
		   SET pShipping = '5-day Shipping';
	END CASE;
END;
$$


SELECT * FROM custumer_info_1;

CALL GetCustomerShipping(6,@pShipping);
SELECT @pShipping;



SELECT 
    ADDRESS
 FROM
    custumer_info_1
WHERE
    ID = 2;
    
    
    
    
    
    