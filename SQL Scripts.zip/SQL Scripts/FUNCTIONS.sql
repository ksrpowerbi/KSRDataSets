DROP FUNCTION calcProfit;
DELIMITER $$  
CREATE FUNCTION calcProfit
(CP FLOAT, 
SP FLOAT) 
RETURNS int
DETERMINISTIC
BEGIN
  DECLARE profit int;
  SET profit = CP-SP;
  RETURN profit;  
END
$$


SELECT calcProfit(100,50);

DROP FUNCTION IF EXISTS SUM_FUNCTION;
DELIMITER $$  
CREATE FUNCTION SUM_FUNCTION(
A INT, 
B INT
) 
RETURNS INT
DETERMINISTIC
Begin
  return a + b;
End
$$

SELECT SUM_FUNCTION(12,3);

SELECT 12+3;

SELECT SUM_FUNCTION(100,50);

SET @x=SUM_FUNCTION(100,200);

select @x;





drop function F_Customer_Occupation;

DELIMITER $$  
CREATE FUNCTION F_Customer_Occupation(  
    age int  
)   
RETURNS VARCHAR(20)    
DETERMINISTIC
BEGIN  
    DECLARE customer_occupation VARCHAR(20);  
    IF age > 35 THEN  
        SET customer_occupation = 'Scientist';  
    ELSEIF (age <= 35 AND  age >= 30) THEN  
        SET customer_occupation = 'Engineer';  
    ELSEIF age < 30 THEN  
        SET customer_occupation = 'Actor';  
    END IF;  
    -- return the customer occupation  
    RETURN (customer_occupation);  -- important
END $$



SELECT F_Customer_Occupation(32);

SET @x=F_Customer_Occupation(85);
select @x;


DROP TABLE IF EXISTS test_cust;
create table test_cust (
id int,
name varchar(20),
age int
);

insert into test_cust VALUES(1,'SANTHOSH',28);
insert into test_cust VALUES (1,'KIRAN',30);
insert into test_cust VALUES (1,'KARTHIK',45);
insert into test_cust VALUES(1,'ARJUN',25);


SELECT * FROM TEST_CUST;

SELECT *, F_Customer_Occupation(AGE) FROM TEST_CUST;


SELECT *, F_Customer_Occupation(AGE) FROM test_cust;


SELECT *, F_Customer_Occupation(AGE) AS OCCUPATION FROM test_cust;


