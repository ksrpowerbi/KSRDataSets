select * from ele_search_tb where orderid = 45;
alter table ele_search_tb add INDEX orderidindex ( orderid);
select * from ele_search_tb where orderid = 45;
alter table ele_search_tb drop INDEX orderidindex;